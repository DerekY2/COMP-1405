# my first python program
print("Hello World")